const { initializeApp } = require("firebase/app");
const { getFirestore, collection, getDocs, doc, setDoc } = require("firebase/firestore");
const config = require("./firebase-applet-config.json");

const app = initializeApp(config);
const db = getFirestore(app, config.firestoreDatabaseId);

async function run() {
  console.log("Testing write to Firestore with databaseId:", config.firestoreDatabaseId);
  const testId = "test-" + Date.now();
  try {
    await setDoc(doc(db, "training_actions", testId), {
      id: testId,
      title: "Test Course Firestore",
      code: "26999",
      createdAt: new Date().toISOString()
    });
    console.log("Successfully wrote to Firestore doc:", testId);
    
    const snap = await getDocs(collection(db, "training_actions"));
    console.log("Total docs in training_actions:", snap.size);
    snap.forEach(d => console.log(" - Doc:", d.id, d.data().title));
  } catch (err) {
    console.error("Firestore error:", err);
  }
}

run();
